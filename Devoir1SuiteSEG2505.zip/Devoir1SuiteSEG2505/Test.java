import java.util.*;
public class Test {

  public static  double perfomanceAnalysis(PointCP p1){
    double tempsP1 = System.currentTimeMillis();
    p1.getX();
    p1.getY();
    p1.getRho();
    p1.getTheta();
    p1.convertStorageToPolar();
    p1.convertStorageToCartesian();
    p1.getDistance(p1);
    p1.rotatePoint(90.0);
    p1.toString();
    double tempsP2 = System.currentTimeMillis() - tempsP1 ;
    return tempsP2;


  }
  public static  double perfomanceAnalysis2(PointCP5 p1){
    double tempsP1 = System.currentTimeMillis();
    p1.getX();
    p1.getY();
    p1.getRho();
    p1.getTheta();
    p1.convertStorage();
    p1.getDistance(p1);
    p1.rotatePoint(90.0);
    p1.toString();
    double tempsP2 = System.currentTimeMillis() - tempsP1 ;
    return tempsP2;


  }

  public static void main(String[] args){

    double a;
    double b;
    char[] c = new char[]{'C', 'P'} ;
    PointCP point;
    int index;
    double tempsCP;
    Random  random = new Random();

    double max, min;
    double median;
    median = 0.0;
    max = min = 0.0;
    for(int i=0; i<10000000;i++){
      a= Math.random() * 100;
      b = Math.random() * 100;
      index = random.nextInt(2);
      point = new PointCP(c[index], a, b);
      tempsCP = perfomanceAnalysis(point);
      if(i==0){
        min = max= tempsCP;
      }
      median =median + tempsCP;
      if(tempsCP> max){
        max= tempsCP;
      }
      if(tempsCP<min){
        min= tempsCP;
      }
    }



    median = median/10000000;
    System.out.println("pointCP: ");
    System.out.println("minimum= "+ min);
    System.out.println("maximum= "+ max);
    System.out.println("mediane= "+ median);

    PointCP5 point2;
    median = 0.0;
    max = min = 0.0;
    for(int i=0; i<10000000;i++){
      a= Math.random() * 100;
      b = Math.random() * 100;
      index = random.nextInt(2);
      if(index==0){
        point2 = new PointCP3(a, b);
      }
      else{
        point2 = new PointCP2(a, b);
      }
      tempsCP = perfomanceAnalysis2(point2);
      if(i==0){
        min = max= tempsCP;
      }
      median =median + tempsCP;
      if(tempsCP> max){
        max= tempsCP;
      }
      if(tempsCP<min){
        min= tempsCP;
      }
    }
    median = median/10000000;
    System.out.println("pointCP5: ");
    System.out.println("minimum= "+ min);
    System.out.println("maximum= "+ max);
    System.out.println("mediane= "+ median);





  }
}
